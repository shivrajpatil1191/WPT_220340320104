const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'cdac',
    database: 'satara',
	port:3306
});
const mysql = require('mysql2');
const express = require("express");
const { cp } = require('fs');
const app = express();


app.use(express.static(cp));
app.get("/findme"),(req,resp)=>{
    let input = req.query.pqr;
    console.log(input);
    let output = {staus:false};
    connection.query("select from book where bookid=?",[input])
     if(res1.length>0)
     {
        output.status= true;
        output.bookdetails = res1[0];
     }
}}; 
}











var result ="";
connection.query("select * from chair where leg = ?", [req.body.xyz.pqr], (err, res1) => {
        if (err) {
            result = err;
			console.log("trouble " + err);
        } else {
            result = res1;
			console.log("success" + result)
        }
		
		console.log("38 " + );
        res.send(result);
    });
	
	
    connection.query('update chair set leg = ? , leg2 = ? where leg3 = ?', [req.body.inp3, req.body.inp2, req.query.body.inp3], (err, res1) => {
        if (err) {
            result = err;
			
        } else {
            result = {
                concept: "so what",
                rws: res1.affectedRows
            };
			
        }
			
        res.send(result);
    });